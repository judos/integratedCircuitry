require "libs.all"

require "prototypes.lamp-panel"
require "prototypes.status-panel"