
require "libs.control.entities" --lets your classes register event functions in general
require "libs.control.gui" --lets your classes register guis

bit = require "libs.bit.numberlua"
  