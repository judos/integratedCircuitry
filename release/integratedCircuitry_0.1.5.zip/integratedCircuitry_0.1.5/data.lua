require "libs.all"

require "prototypes.lamp-panel"
require "prototypes.status-panel"
require "prototypes.circuit-pole"

require "prototypes.compact-combinator"
require "prototypes.compact-combinator-power"