require "libs.all"

require "prototypes.lamp-panel"
require "prototypes.status-panel"
require "prototypes.memory-combinator"
require "prototypes.filter-combinator"
require "prototypes.circuit-pole"