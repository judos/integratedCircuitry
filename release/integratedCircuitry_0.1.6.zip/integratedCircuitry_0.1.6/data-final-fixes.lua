



data.raw["lamp"]["small-lamp"].fast_replaceable_group = "lamp"