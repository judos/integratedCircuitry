
modVersion = "0.0.1" --version of control data, only updated when control.lua changes
modName = "integratedCircuitry" -- required prefix for all ui name components which can be clicked
fullModName = "integratedCircuitry" -- required for logging and prototypes


libLog.debug_master = true
--libLog.testing = true
--libLog.testing = false
--libLog.debug_level = 1  -- 1=info 2=warn 3=error