
local fix = deepcopy(data.raw["container"]["wooden-chest"])
overwriteContent(fix, {
	name = "energy-network-identificator-entity",
	order = "a"
})

data:extend({	fix })