require "libs.control.entityId"

local identificatorName = "energy-network-identificator-entity"



function buildElectricPole(entity)
	if entity.type ~= "electric-pole" then
		return
	end
	local wireDistance = entity.prototype.max_wire_distance
	local searchRadius = wireDistance*2
	
	local connectedTo = {}
	local neighbours = entity.neighbours["copper"]
--	print("neighbours: "..tostring(#neighbours))
	for _,neighbour in pairs(neighbours) do
		if connectedTo[idOfEntity(neighbour)] then
			entity.disconnect_neighbour(neighbour)
		else
			entity.disconnect_neighbour(neighbour)
			local connectedPoles = allIndirectNeighboursInRange(neighbour,searchRadius)
	--		print("found indirect: "..serpent.block(connectedPoles))
			table.addTable(connectedTo,connectedPoles)
			entity.connect_neighbour(neighbour)
		end
	end
	
	entity.electric_network_statistics.set_input_count(identificatorName, 0)
end


function distance(position1, position2)
  return ((position1.x - position2.x)^2 + (position1.y - position2.y)^2)^0.5
end


function allIndirectNeighboursInRange(neighbour,searchRadius)
	local toSearch = { neighbour }
	local foundSet = {}
	function inRange(entity)
		return distance(entity.position,neighbour.position) <= searchRadius
	end
	
	while #toSearch > 0 do
		local neighbour = table.remove(toSearch)
		local neighbours = neighbour.neighbours["copper"]
		for _,indirectNeighbour in pairs(neighbours) do
			if inRange(indirectNeighbour) and not foundSet[idOfEntity(indirectNeighbour)] then
				table.insert(toSearch,indirectNeighbour)
			end
		end
		foundSet[idOfEntity(neighbour)] = true
	end
	return foundSet
end