require "libs.all"

require "prototypes.lamp-panel"
require "prototypes.status-panel"
require "prototypes.memory-combinator"
require "prototypes.energy-network-identificator-entity"