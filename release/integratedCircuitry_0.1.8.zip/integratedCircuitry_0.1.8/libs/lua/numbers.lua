
function isint(n)
  return n==math.floor(n)
end